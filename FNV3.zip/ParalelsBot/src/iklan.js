const iklan1 = (pushname, prefix, botName, ownerName) => { 
	return `🔰 -----[ *「 IKLAN ${botName} 」* ]----- 🔰
──────────────────────────────
◯ *+------------+ FN HOSTINGER +------------+

Paket Premium: 
[+] 5 bulan -> 40K
[+] 1 TAHUN -> 110K

Paket Normal
[+] 1 bulan -> 15K
[+] 2 bulan -> 25K
[+] 3 bulan -> 35K

Normal Fiture: Costume Owner, Nama Bot

Premium Fiture: Costume GitHub, Bisa Pake Github Sendiri, bisa pake SC

Pay: ovo, gopay, pulsa

AYO BELI, MURAH² PASTI ANDA SUKA :) 

Buat Bot Ribet, Haha, Buat Apa, Di Sini Tinggal Scan Doank Bro, Di Sini Mah 100% Terpercaya

Grup Link: bit.ly/fnhosting

1 | TESTI*
──────────────────────────────
◯ *JIKA MINAT IKLAN DIATAS*
◯ *HARAP HUBUNGI NOMOR DIBAWAH :*
◯ *wa.me/15032726485*
──────────────────────────────
🔰 -----[ *「 POWERED BY ${ownerName} 」* ]----- 🔰
`
}

exports.iklan1 = iklan1